<?php

class AllianceConfig
{
    public const ALLIANCE_PAYMENT_CODE = 'alliance';
}
