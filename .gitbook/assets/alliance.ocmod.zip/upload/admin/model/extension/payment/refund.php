<?php

class ModelExtensionPaymentRefund extends Model
{
    public function __construct(Registry $registry)
    {
        parent::__construct($registry);
        $this->load->library('AllianceConfig');
        $this->load->library('AllianceEcom');
        $this->load->library('AllianceLogger');
        $this->load->model('extension/payment/alliance');
        $this->load->model('extension/payment/history');
        $this->ecom = new AllianceEcom($registry);
        $this->logger = new AllianceLogger($registry);
    }

    /**
     * @param int $orderId
     * @return array
     * @throws GuzzleException
     */
    public function refundOrder(int $orderId)
    {
        $data = [];
        if (!empty($orderId)) {
            try {
                $allianceOrderCallBack = $this->model_extension_payment_alliance
                    ->getAllianceOrderCallback($orderId);

                if (empty($allianceOrderCallBack)) {
                    $allianceOrder = $this->model_extension_payment_alliance->getAllianceOrder($orderId);
                    $jwe_token = $this->ecom->authorizeByVirtualDevice(
                        $this->config->get('payment_alliance_service_code_id')
                    );
                    $decrypt_auth = $this->ecom->decryptResponse($jwe_token);
                    $eComResponse = $this->ecom->checkOperationStatus(
                        $decrypt_auth,
                        $allianceOrder['hpp_order_id']
                    );
                    $allianceOrderCallBack = $this->prepareCallBackData($eComResponse);
                }

                $jwe_token = $this->ecom->authorizeByVirtualDevice(
                    $this->config->get(
                        'payment_alliance_service_code_id'
                    )
                );
                $data = [];
                $decrypt_auth = $this->ecom->decryptResponse($jwe_token);
                $data = $this->ecom->proceedRefund(
                    $decrypt_auth,
                    $this->url,
                    $allianceOrderCallBack
                );

                if (!empty($data['msgType']) && $data['msgType'] == 'ERROR') {
                    $this->logger->log(
                        'Refound error: ' . $data['msgText'] ?? '',
                        LogLevel::ERROR
                    );
                }

                $this->model_extension_payment_history->updateRefundHistory(
                    $data,
                    $orderId
                );
                $this->model_extension_payment_history->updateOrderHistoryAndStatus(
                    (int) $orderId,
                    (int) $this->config->get('payment_alliance_refunded_status'),
                    'Повернення коштів через Alliance Payment'
                );
                $data['message'] = 'Повернення коштів здійснено';

            } catch (Exception $e) {
                $data['message'] = $e->getMessage();
                $this->model_extension_payment_history->updateOrderHistoryAndStatus(
                    (int) $orderId,
                    (int) $this->config->get('payment_alliance_refund_fail_status'),
                    $e->getMessage()
                );
            }
        } else {
            $data['message'] = 'Щось пішло не так :(';
        }

        return $data;
    }

    /**
     * @param array $operationStatusData
     * @return array
     */
    public function prepareCallBackData(array $operationStatusData)
    {
        $data = [];

        if (isset($operationStatusData['operations'][0]['operationId'])) {
            $data['operation_id'] = $operationStatusData['operations'][0]['operationId'];
        } elseif (isset($operationStatusData['operations']['operationId'])) {
            $data['operation_id'] = $operationStatusData['operations']['operationId'];
        }

        $data['merchant_id'] = $operationStatusData['merchantId'] ?? '';
        $data['merchant_request_id'] = $operationStatusData['merchantRequestId'] ?? '';
        $data['coin_amount'] = $operationStatusData['coinAmount'] ?? '';

        return $data;
    }

    public function checkIfOrderRefunded(int $orderId): bool
    {
        $order = $this->model_extension_payment_history->getRefundOrder($orderId);

        return !empty($order);
    }
}
