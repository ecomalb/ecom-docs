<?php
/**
 * Copyright © 2025 Alliance Dgtl. https://alb.ua/uk
 */

declare(strict_types=1);

namespace AlliancePay\Repository;

use Doctrine\ORM\EntityRepository;

/**
 * Class AllianceOrderRepository.
 */
class RefundRepository extends EntityRepository
{

}
