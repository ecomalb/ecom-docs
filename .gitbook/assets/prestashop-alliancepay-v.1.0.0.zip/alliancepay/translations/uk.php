<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{alliancepay}prestashop>alliancepay_688e324c13d26247a23487c0de140940'] = 'Платіжний модуль для PrestaShop.';
$_MODULE['<{alliancepay}prestashop>alliancepay_bb8956c67b82c7444a80c6b2433dd8b4'] = 'Ви впевнені що хочете видалити модуль?';
$_MODULE['<{alliancepay}prestashop>alliancepay_2c1c82d6760a8e6e5ad4d708ee01b664'] = 'Додаткова інформація';
$_MODULE['<{alliancepay}prestashop>payment_34ec351c8efb82de59ebef44a082f699'] = 'Ваш платіж не вдалося обробити. Помилка валідації замовлення. Будь ласка, спробуйте ще раз.';
$_MODULE['<{alliancepay}prestashop>payment_540b884fe0cbb86310d324c42daccdda'] = 'Оплата не вдалася. Будь ласка, спробуйте ще раз.';
$_MODULE['<{alliancepay}prestashop>payment_c1d979bb64871e42e9d35c09762679f6'] = 'Не вдалося обробити ваш платіж. Будь ласка, спробуйте ще раз.';
$_MODULE['<{alliancepay}prestashop>payment_50362aa5a846010bb82f783fe8ddda2d'] = 'Оплата через захищену сторінку Альянс Банку.';
$_MODULE['<{alliancepay}prestashop>payment_4e33b61812cee2c7d4745f3324d6ebd9'] = 'Вас буде перенаправлено на сторінку оплати.';
$_MODULE['<{alliancepay}prestashop>refundprocessor_4b0ec232008fdb835f038e282e913b3d'] = 'Помилка повернення коштів.';
