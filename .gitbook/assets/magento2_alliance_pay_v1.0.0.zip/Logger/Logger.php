<?php
/**
 * Copyright © 2025 Alliance Dgtl. https://alb.ua/uk
 */

declare(strict_types=1);

namespace Alliance\AlliancePay\Logger;

use Monolog\Logger as MonologLogger;

/**
 * Class Logger.
 */
class Logger extends MonologLogger
{
}
