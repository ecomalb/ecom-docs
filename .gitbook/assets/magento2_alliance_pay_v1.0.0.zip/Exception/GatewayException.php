<?php
/**
 * Copyright © 2025 Alliance Dgtl. https://alb.ua/uk
 */

declare(strict_types=1);

namespace Alliance\AlliancePay\Exception;

use Magento\Framework\Exception\LocalizedException;

/**
 * Class GatewayException.
 */
class GatewayException extends LocalizedException
{

}
