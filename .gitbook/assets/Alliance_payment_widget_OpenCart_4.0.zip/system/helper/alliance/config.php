<?php

declare(strict_types=1);

namespace Opencart\System\Helper\Alliance;

/**
 * Class Config.
 */
class Config
{
    public const ALLIANCE_BASE_CONFIG_KEY = 'payment_alliance';
    public const ALLIANCE_PAYMENT_CODE = 'alliance.alliance';
}
