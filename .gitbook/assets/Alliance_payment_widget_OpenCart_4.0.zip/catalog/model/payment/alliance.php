<?php
namespace Opencart\Catalog\Model\Extension\Alliance\Payment;

class Alliance extends \Opencart\System\Engine\Model
{
	/**
	 * getMethods
	 *
	 * @param  mixed $address
	 * @return array
	 */
	public function getMethods(array $address = []): array
	{
		$this->load->language("extension/alliance/payment/alliance");

		$option_data["alliance"] = [
			"code" => "alliance.alliance",
			"name" => $this->language->get("text_title"),
		];

		return [
			"code" => "alliance",
			"name" => $this->language->get("heading_title"),
			"option" => $option_data,
			"sort_order" => $this->config->get("payment_alliance_sort_order"),
		];
	}

	public function getAllianceOrder($hpp_order_id)
	{
		$query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "alliance_checkout_integration_order` WHERE `hpp_order_id` = '" . $hpp_order_id . "'");

		return $query->row;
	}

	public function saveAllianceOrder(array $data, int $order_id): void
	{
		$this->load->model('checkout/order');

        if ($data['orderStatus'] == "PENDING" || $data['orderStatus'] == 'REQUIRED_3DS'){
            $this->model_checkout_order->addHistory($order_id, $this->config->get("payment_alliance_pending_status"));
        }

        if ($data['orderStatus'] == "FAIL"){
            $this->model_checkout_order->addHistory($order_id, $this->config->get("payment_alliance_error_status"));
        }

        $sql = "INSERT INTO `" . DB_PREFIX . "alliance_checkout_integration_order` SET";

        $implode = [];

		if (!empty($order_id)) {
			$implode[] = "`order_id` = '" . $order_id . "'";
		}

		if (!empty($data['merchantRequestId'])) {
			$implode[] = "`merchant_request_id` = '" . $this->db->escape($data['merchantRequestId']) . "'";
		}

		if (!empty($data['hppOrderId'])) {
			$implode[] = "`hpp_order_id` = '" . $this->db->escape($data['hppOrderId']) . "'";
		}

		if (!empty($data['merchantId'])) {
			$implode[] = "`merchant_id` = '" . $this->db->escape($data['merchantId']) . "'";
		}

		if (!empty($data['coinAmount'])) {
			$implode[] = "`coin_amount` = '" . (int) $data['coinAmount'] . "'";
		}

		if (!empty($data['hppPayType'])) {
			$implode[] = "`hpp_pay_type` = '" . $this->db->escape($data['hppPayType']) . "'";
		}

		if (!empty($data['orderStatus'])) {
			$implode[] = "`order_status` = '" . $this->db->escape($data['orderStatus']) . "'";
		}

		if (!empty($data['paymentMethods'])) {
			$paymentMethods = json_encode($data['paymentMethods']);
			$implode[] = "`payment_methods` = '" . $this->db->escape($paymentMethods) . "'";
		}

		if (!empty($data['createDate'])) {
			$implode[] = "`create_date` = '" . $this->db->escape($data['createDate']) . "'";
		}

		if (!empty($data['expiredOrderDate'])) {
			$implode[] = "`expired_order_date` = '" . $this->db->escape($data['expiredOrderDate']) . "'";
		}

		if ($implode) {
			$sql .= implode(", ", $implode);
		}

		$this->db->query($sql);
	}

	public function saveCallBack(array $data, int $order_id): void
	{
		$this->load->model('checkout/order');

        if ($data['orderStatus'] == "PENDING" || $data['orderStatus'] == 'REQUIRED_3DS'){
            $this->model_checkout_order->addHistory($order_id, $this->config->get("payment_alliance_pending_status"));
        }

        if ($data['orderStatus'] == "FAIL"){
            $this->model_checkout_order->addHistory($order_id, $this->config->get("payment_alliance_error_status"));
        }

        if ($data['orderStatus'] == "SUCCESS"){
            $this->model_checkout_order->addHistory($order_id, $this->config->get("payment_alliance_paid_status"));
        }

		$sql = "INSERT INTO `" . DB_PREFIX . "alliance_checkout_integration_order_callback` SET";

		$implode = [];

		if (!empty($order_id)) {
			$implode[] = "`order_id` = '" . $order_id . "'";
		}

		if (!empty($data['ecomOrderId'])) {
			$implode[] = "`ecom_order_id` = '" . $this->db->escape($data['ecomOrderId']) . "'";
		}

		if (!empty($data['coinAmount'])) {
			$implode[] = "`coin_amount` = '" . (int) $this->db->escape($data['coinAmount']) . "'";
		}

		if (!empty($data['merchantId'])) {
			$implode[] = "`merchant_id` = '" . $this->db->escape($data['merchantId']) . "'";
		}

		if (!empty($data['statusUrl'])) {
			$implode[] = "`status_url` = '" . $data['statusUrl'] . "'";
		}

		if (!empty($data['hppOrderId'])) {
			$implode[] = "`hpp_order_id` = '" . $this->db->escape($data['hppOrderId']) . "'";
		}

		if (!empty($data['redirectUrl'])) {
			$implode[] = "`redirect_url` = '" . $this->db->escape($data['redirectUrl']) . "'";
		}

		if (!empty($data['notificationUrl'])) {
			$implode[] = "`notification_url` = '" . $this->db->escape($data['notificationUrl']) . "'";
		}

		if (!empty($data['hppPayType'])) {
			$implode[] = "`hpp_pay_type` = '" . $this->db->escape($data['hppPayType']) . "'";
		}

		if (!empty($data['merchantRequestId'])) {
			$implode[] = "`merchant_request_id` = '" . $this->db->escape($data['merchantRequestId']) . "'";
		}

		if (!empty($data['orderStatus'])) {
			$implode[] = "`order_status` = '" . $this->db->escape($data['orderStatus']) . "'";
		}

		$operation_id = $this->getOperationId($data);
		if (!empty($operation_id)) {
			$implode[] = "`operation_id` = '" . $this->db->escape($operation_id) . "'";
		}

		if (!empty($data['createDate'])) {
			$implode[] = "`create_date` = '" . $this->db->escape($data['createDate']) . "'";
		}

		if (!empty($data['paymentMethods'])) {
			$paymentMethods = json_encode($data['paymentMethods']);
			$implode[] = "`payment_methods` = '" . $this->db->escape($paymentMethods) . "'";
			//$implode[] = "`payment_methods` = '" . $this->db->escape(implode(',', $data['paymentMethods'])) . "'";
		}

		if (!empty($data['expiredOrderDate'])) {
			$implode[] = "`expired_order_date` = '" . $this->db->escape($data['expiredOrderDate']) . "'";
		}

		if (!empty($data['operations'])) {
			$operationsJson = json_encode($data['operations']);
			$implode[] = "`operations` = '" . $this->db->escape($operationsJson) . "'";
			//$implode[] = "`operations` = '" . $this->db->escape(implode(',', $data['operations'])) . "'";
		}

		if ($implode) {
			$sql .= implode(", ", $implode);
		}

		$this->db->query($sql);
	}

	private function getOperationId(array $data)
	{
		if (isset($data['operations'][0]['operationId'])) {
			return $data['operations'][0]['operationId'];
		} elseif (isset($data['operations']['operationId'])) {
			return $data['operations']['operationId'];
		}

		return null;
	}

	public function clearCart(object $session): void
	{
		$this->cart->clear();

		unset($session->data['order_id']);
		unset($session->data['payment_method']);
		unset($session->data['payment_methods']);
		unset($session->data['shipping_method']);
		unset($session->data['shipping_methods']);
		unset($session->data['comment']);
		unset($session->data['agree']);
		unset($session->data['coupon']);
		unset($session->data['reward']);
	}

	public function cartTotalPrice()
	{
		$this->load->model('checkout/cart');

		$totals = [];
		$taxes = $this->cart->getTaxes();
		$total = 0;

		($this->model_checkout_cart->getTotals)($totals, $taxes, $total);

		return $totals[array_key_last($totals)]['value'];
	}
}
