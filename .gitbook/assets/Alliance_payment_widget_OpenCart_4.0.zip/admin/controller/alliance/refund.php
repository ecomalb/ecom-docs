<?php

namespace Opencart\Admin\Controller\Extension\Alliance\Alliance;

use GuzzleHttp\Exception\GuzzleException;
use Opencart\System\Engine\Controller;
use Opencart\System\Engine\Registry;
use Opencart\System\Helper\Alliance\Config;

/**
 * Class Refund.
 */
class Refund extends Controller
{
    public function __construct(Registry $registry)
    {
        parent::__construct($registry);
        $this->load->model('sale/order');
        $this->load->model('extension/alliance/payment/refund');
    }

    /**
     * @param string $route
     * @param array $args
     * @param mixed $output
     * @return void
     */
    public function injectRefundButton(string &$route, array &$args, mixed &$output): void
    {
        $buttonHtml = '';
        $order_id = (int)$this->request->get['order_id'];
        $order_info = $this->model_sale_order->getOrder($order_id);
        $isRefunded = $this->model_extension_alliance_payment_refund->checkIfOrderRefunded((int) $order_id);

        if ($order_info['payment_method']['code'] === Config::ALLIANCE_PAYMENT_CODE) {
            $disabled = !$isRefunded ? 0 : 1;
            $buttonHtml = '
            <script>
                document.addEventListener("DOMContentLoaded", function() {
                    let isDisabled = Boolean(' . $disabled . ');
                    const container = document.querySelector(".page-header .float-end");
                    if (container) {
                        const btn = document.createElement("button");
                        btn.className = "btn btn-danger";
                        btn.style = "margin-right:5px;";
                        if (isDisabled) {
                            btn.disabled = true;
                        }
                        btn.innerHTML = \'<i class="fa fa-undo"></i> Повернення коштів\';
                        btn.addEventListener("click", function() {
                            const orderId = new URLSearchParams(window.location.search).get("order_id");
                            fetch("index.php?route=extension/alliance/alliance/refund|refund&user_token='
                                . $this->getUserToken() . '&order_id=" + orderId)
                                .then(r => r.json())
                                .then(res => alert(res.message || "Refund complete!"))
                                .catch(err => alert(res.message || "Refund failed!"));
                        });
                        container.prepend(btn);
                    }
                });
            </script>';
        }

        $output = str_replace('</body>', $buttonHtml . '</body>', $output);
    }

    /**
     * @return void
     * @throws GuzzleException
     */
    public function refund(): void
    {
        $orderId = $this->request->get['order_id'] ?? 0;
        $data = $this->model_extension_alliance_payment_refund->refundOrder($orderId);
        $this->response->addHeader("Content-Type: application/json");
        $this->response->setOutput(json_encode($data));
    }

    /**
     * @return string
     */
    private function getUserToken(): string
    {
        $session = $this->session;

        return $session->data['user_token'];
    }
}
