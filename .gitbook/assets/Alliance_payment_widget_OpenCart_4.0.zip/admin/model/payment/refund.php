<?php

declare(strict_types=1);

namespace Opencart\Admin\Model\Extension\Alliance\Payment;

use Exception;
use GuzzleHttp\Exception\GuzzleException;
use Opencart\System\Engine\Model;
use Opencart\System\Engine\Registry;
use Opencart\System\Helper\Alliance\Ecom;
use Opencart\System\Helper\Alliance\log\AllianceLogger;
use Psr\Log\LogLevel;

class Refund extends Model
{
    public function __construct(Registry $registry)
    {
        parent::__construct($registry);
        // extension/alliance/system/helper/alliance/config.php
        $this->load->helper('extension/alliance/alliance/config');
        // extension/alliance/system/helper/alliance/ecom.php
        $this->load->helper('extension/alliance/alliance/ecom');
        // extension/alliance/system/helper/alliance/log/alliancelogger.php
        $this->load->helper('extension/alliance/alliance/log/alliancelogger');
        // extension/alliance/admin/model/payment/alliance.php
        $this->load->model('extension/alliance/payment/alliance');
        // extension/alliance/admin/model/payment/refund/history.php
        $this->load->model('extension/alliance/payment/refund/history');
        $this->ecom = new Ecom($registry);
        $this->logger = new AllianceLogger($registry);
    }

    /**
     * @param int $orderId
     * @return array
     * @throws GuzzleException
     */
    public function refundOrder(int $orderId): array
    {
        $data = [];
        if (!empty($orderId)) {
            try {
                $allianceOrderCallBack = $this->model_extension_alliance_payment_alliance
                    ->getAllianceOrderCallback($orderId);

                if (empty($allianceOrderCallBack)) {
                    $allianceOrder = $this->model_extension_alliance_payment_alliance->getAllianceOrder($orderId);
                    $jwe_token = $this->ecom->authorizeByVirtualDevice(
                        $this->config->get('payment_alliance_service_code_id')
                    );
                    $decrypt_auth = $this->ecom->decryptResponse($jwe_token);
                    $eComResponse = $this->ecom->checkOperationStatus(
                        $decrypt_auth,
                        $allianceOrder['hpp_order_id']
                    );
                    $allianceOrderCallBack = $this->prepareCallBackData($eComResponse);
                }

                $jwe_token = $this->ecom->authorizeByVirtualDevice(
                    $this->config->get(
                        'payment_alliance_service_code_id'
                    )
                );
                $data = [];
                $decrypt_auth = $this->ecom->decryptResponse($jwe_token);
                $data = $this->ecom->proceedRefund(
                    $decrypt_auth,
                    $this->url,
                    $allianceOrderCallBack
                );

                if (!empty($data['msgType']) && $data['msgType'] == 'ERROR') {
                    $this->logger->log(
                        'Refound error: ' . $data['msgText'] ?? '',
                        LogLevel::ERROR
                    );
                }

                $this->model_extension_alliance_payment_refund_history->updateRefundHistory(
                    $data,
                    $orderId
                );
                $this->model_extension_alliance_payment_refund_history->updateOrderHistoryAndStatus(
                    (int) $orderId,
                    (int) $this->config->get('payment_alliance_refunded_status'),
                    'Повернення коштів через Alliance Payment'
                );
                $data['message'] = 'Повернення коштів здійснено';

            } catch (Exception $e) {
                $data['message'] = $e->getMessage();
                $this->model_extension_alliance_payment_refund_history->updateOrderHistoryAndStatus(
                    (int) $orderId,
                    (int) $this->config->get('payment_alliance_refund_fail_status'),
                    $e->getMessage()
                );
            }
        } else {
            $data['message'] = 'Щось пішло не так :(';
        }

        return $data;
    }

    /**
     * @param array $operationStatusData
     * @return array
     */
    public function prepareCallBackData(array $operationStatusData): array
    {
        $data = [];

        if (isset($operationStatusData['operations'][0]['operationId'])) {
            $data['operation_id'] = $operationStatusData['operations'][0]['operationId'];
        } elseif (isset($operationStatusData['operations']['operationId'])) {
            $data['operation_id'] = $operationStatusData['operations']['operationId'];
        }

        $data['merchant_id'] = $operationStatusData['merchantId'] ?? '';
        $data['merchant_request_id'] = $operationStatusData['merchantRequestId'] ?? '';
        $data['coin_amount'] = $operationStatusData['coinAmount'] ?? '';

        return $data;
    }

    public function checkIfOrderRefunded(int $orderId): bool
    {
        $order = $this->model_extension_alliance_payment_refund_history->getRefundOrder($orderId);

        return !empty($order);
    }
}
