<?php

declare(strict_types=1);

namespace Opencart\Admin\Model\Extension\Alliance\Payment\Refund;

use Opencart\System\Engine\Registry;
use Opencart\System\Helper\Alliance\Db\RefundHistoryMapper;

class History extends \Opencart\System\Engine\Model
{
    public function __construct(Registry $registry)
    {
        parent::__construct($registry);
        // extension/alliance/system/helper/alliance/db/refund.php
        $this->load->helper('extension/alliance/alliance/db/refundhistorymapper');
    }

    /**
     * @param array $data
     * @param int $orderId
     * @return void
     */
    public function updateRefundHistory(array $data, int $orderId): void
    {
        if (!empty($data) && !empty($orderId)) {
            $sql = "INSERT INTO `" . DB_PREFIX . "alliance_integration_order_refund` SET";

            $implode = [];
            $implode[] = "`order_id` = '" . $orderId . "'";

            foreach (RefundHistoryMapper::REFUND_DATA_HISTORY_FIELDS_MAPPING as $key => $dbField) {
                if (empty($data[$key])) {
                    continue;
                }
                $value = in_array($key, RefundHistoryMapper::JSON_ENCODED_FIELDS_LIST)
                    ? json_encode($data[$key])
                    : (string) $data[$key];
                $implode[] = sprintf("`%s` = '%s'", $dbField, $this->db->escape($value));
            }

            if ($implode) {
                $sql .= implode(", ", $implode);
            }

            $this->db->query($sql);
        }
    }

    public function getRefundOrder(int $orderId): ?array
    {
        $query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "alliance_integration_order_refund` WHERE `order_id` = '" . $orderId . "'");

        return $query->row;
    }

    public function updateOrderHistoryAndStatus(
        int $orderId,
        int $orderStatusId,
        string $comment = '',
        int $orderNotify = 0
    ): void {
        $this->db->query(
            "UPDATE `" . DB_PREFIX . "order` SET order_status_id = '" . $orderStatusId
            . "', date_modified = NOW() WHERE order_id = '" . (int)$orderId . "'");

        $this->db->query("INSERT INTO `" . DB_PREFIX . "order_history` SET order_id = '" . $orderId
            . "',order_status_id = '" . $orderStatusId . "',notify = '" . $orderNotify
            . "',comment = '" . $this->db->escape($comment)
            . "',date_added = NOW()");
    }
}
